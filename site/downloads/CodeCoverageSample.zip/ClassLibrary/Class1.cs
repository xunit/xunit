﻿namespace ClassLibrary
{
    public class Class1
    {
        public static int Add(int x, int y) =>
            x + y;

        public static int Subtract(int x, int y) =>
            x - y;
    }
}